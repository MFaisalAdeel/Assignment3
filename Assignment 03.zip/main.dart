void main() {
Person myperson = Person("Faisal","Male",38);
  myperson.showinfo();
  Student mystudent = Student('Sara','Female',12,"Grade A");
  mystudent.showinfo();
}

class Person{
String? name,gender;
int? age;

  Person(this.name, this.gender,this.age);
 
  showinfo(){
  print('Person: $name,$gender,$age');
}
}
class Student extends Person{
  String? gradelevel;
  Student(String name,gender,int age,this.gradelevel):super(name,gender,age);
  @override
  showinfo(){
    print('Student: $name,$gender,$age,$gradelevel');
    
  }
}